import java.util.Scanner;

public class Year {
    public static void main(String[] args){
        int numero;
        Scanner input = new Scanner(System.in);
        System.out.print("Please, insert a year: ");
        numero = input.nextInt();

        if (numero%4 == 0) {
            if (numero%100 == 0 && numero%400 == 0)
                System.out.println("Bisestile non secolare.");
            else
                System.out.println("Bisestile secolare");
        }
        else
            System.out.println("Non Bisestile");
        input.close();
    }    
}
