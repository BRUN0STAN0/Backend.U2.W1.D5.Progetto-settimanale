public class Loop {
    public static void main(String[] args){
      
        int numero = 0;
        while (numero != 100){
            numero++;
            System.out.println(numero);
        }
    }
}
