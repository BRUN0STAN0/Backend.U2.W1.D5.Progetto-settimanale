import java.util.Scanner;

public class sequenceNumber {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int sequence;
        int insertMax = 5;
        boolean exist = true;


        while(insertMax != 0){
            insertMax--;
            sequence = input.nextInt();
            if(sequence %5 == 0)
                exist = false;
        }
        if (!exist) //exist = false
        {
            System.out.println("At least one.");
        }
        else
            System.out.println("No one.");
        input.close();
    }
}
