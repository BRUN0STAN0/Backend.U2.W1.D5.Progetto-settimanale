public class Time {
    public static void main(String[] args) {
        int hour = 19;
        int minute = 27;
        int second = 23;
        int totSecond = 0;

        totSecond = hour * 3600 + minute * 60 + second;
        System.out.println("The total second since midnight is "+totSecond);

        totSecond -= 24*3600;
        System.out.println("The second remaining in this day is "+totSecond);
        totSecond += 24*3600;

        totSecond = (totSecond * 100) / (24*3600);
        System.out.println("The percentage of the day has passed is: "+totSecond+"%");
    }
    
}
