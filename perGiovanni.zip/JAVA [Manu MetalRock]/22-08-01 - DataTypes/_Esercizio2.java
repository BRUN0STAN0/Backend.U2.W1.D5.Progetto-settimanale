import java.util.Scanner;

public class _Esercizio2 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Insert an integer number: ");
        int number = input.nextInt();
        int count = 0;

        while (number != 0) {
            System.out.print("Insert an integer number: ");
            number = input.nextInt();
            if (number %3==0 && number%2!=0)
                count++;
        }

        System.out.printf("The total numbers odd, and divisible per 3 is: %d", count);

        input.close();
    }
}
