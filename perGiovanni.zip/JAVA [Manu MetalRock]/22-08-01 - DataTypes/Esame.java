import java.util.Scanner;

public class Esame {
    public static void main(String[] args) {
        int a;
        
        Scanner input = new Scanner(System.in);

        System.out.print("Insert a vote: ");
        a = input.nextInt();


        if (a < 0 || a > 30) // (0 < a < 30)
            System.out.println("Please, insert a valide vote. (From 0 to 30)");
        else if (a >= 18)
            System.out.println("Congratulation! Exam passed!");
        else
            System.out.println("Exam failed.");
        input.close();    
    }
    
}