import java.util.Scanner;

public class CartaIdentita {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String name, surname, city, gender;
        int age;

        System.out.print("Inserire il nome: ");
        name = input.nextLine();
        System.out.print("Inserire il cognome: ");
        surname = input.nextLine();
        System.out.print("Inserire la città: ");
        city = input.nextLine();
        System.out.print("Inserire il genere: ");
        gender = input.nextLine();
        System.out.print("Inserire l'eta: ");
        age = input.nextInt();
        System.out.println("  ");

        System.out.println(name+"\n"+surname+"\n"+city+"\n"+gender+"\n"+age+"\n");
        System.out.printf("%s\n%s\n%s\n%s\n%s\n", name, surname, city, gender, age);
        input.close();
    }
}