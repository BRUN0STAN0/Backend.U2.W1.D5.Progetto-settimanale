import java.util.Scanner;

public class pariDispari {
    public static void main(String[] args) {
        int a;
        
        Scanner input = new Scanner(System.in);

        System.out.print("Insert a value: ");
        a = input.nextInt();


        if (a % 2 != 0)
            System.out.println("ODD(dispari)");
        else
            System.out.println("EVEN(pari)");
        input.close();
    }
    
}