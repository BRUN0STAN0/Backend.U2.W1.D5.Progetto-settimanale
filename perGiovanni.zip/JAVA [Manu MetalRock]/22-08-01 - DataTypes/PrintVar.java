public class PrintVar {
    public static void main(String[] args){
        String primaLinea = "Ciao Mondo";
        System.out.println("Il valore della primaLinea è "+primaLinea);

        int ore = 11;
        int minuti = 59;
        System.out.println("Sono le ore " + ore +":" +minuti+ ".");

        System.out.println("Numero di minuti dall'ultima mezzanotte: "+(ore*60+minuti));
    }
    
}
