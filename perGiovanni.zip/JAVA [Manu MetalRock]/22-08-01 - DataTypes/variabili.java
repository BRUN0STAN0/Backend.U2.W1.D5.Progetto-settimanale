public class variabili {
    public static void main(String[] args) {
        int x = 10;
        int y = 3 * x + 5;
        System.out.println(y);
    }
}
