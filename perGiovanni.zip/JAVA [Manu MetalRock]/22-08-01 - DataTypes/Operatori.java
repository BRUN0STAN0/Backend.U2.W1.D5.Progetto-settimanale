public class Operatori {
    public static void main(String[] args) {

        int A = 5;
        int B = 3;

        System.out.println(A+B);
        System.out.println(A-B);
        System.out.println(A*B);
        System.out.println(A/B);
        System.out.println(A%B);
    }
}
