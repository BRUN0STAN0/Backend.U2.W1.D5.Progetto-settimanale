import java.util.Scanner;

public class _Esercizio1 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int x, y;
        System.out.print("Insert the value of \"x\": ");
        x = input.nextInt();
        System.out.print("Insert the value of \"y\": ");
        y = input.nextInt();
        int sum = 0;

        if (x>y)
            System.out.println("ERROR: x must be less than y.");

        while (x<=y) {
            if (x%2 != 0){ //if odd
                sum += x;
                System.out.println("I founded an odd number: "+x);
            }
            x++;
        }

        System.out.println("The sum of the ODD value betwen x and y is:"+sum);
        input.close();
    }
    
}
