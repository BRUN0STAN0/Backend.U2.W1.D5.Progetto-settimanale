public class Date {
    public static void main(String[] args) {

    System.out.println("Hello World");
    String dayweek = "Friday";
    String month = "July";
    int day = 16;
    int year = 2015;

    System.out.println("American format:\n"+dayweek+", "+month+" "+day+", "+year);
    System.out.println("European format:\n"+dayweek+", "+day+" "+month+", "+year);
     }
    
}
