import java.util.Scanner;

public class ConditionsStatement {
    public static void main(String[] args) {
        int a, b;
        
        Scanner input = new Scanner(System.in);

        System.out.print("Insert \"a\" value: ");
        a = input.nextInt();
        System.out.print("Insert \"b\" value: ");
        b = input.nextInt();

        if (a < b)
            System.out.println("a is lower than b.");
        else if (a == b)
            System.out.println("a is equal b.");
        else 
            System.out.println("a is greater than b.");
            input.close();
    }
    
}
