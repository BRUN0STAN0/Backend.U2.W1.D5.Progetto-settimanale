public class SummationNumbers {
    public static void main(String[] args) {
        int sum = 0;
        int x = 0;

        while (x<10) {
            sum += x;
            x++;
        }
        System.out.println("Summation: "+sum);
    }
    
}
