import java.util.Scanner;

public class _Esercizio3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Insert a integer number: ");
        int N = input.nextInt();
        int read;
        boolean foundZero = false;

        while (N!=0){
            read = N%10;
            if (read==0){
                foundZero = true;
                break;
            }
            else
                N /= 10;
        }
        
        if (foundZero)
            System.out.println("I found the number 0.");
        else
            System.out.println("No one number 0.");

        input.close();
    }
}
