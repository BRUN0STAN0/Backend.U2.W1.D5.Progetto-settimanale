public class DatiCircle {

    private double raggio;
    
    public void setRaggio(double r) {
        this.raggio = r;
    }

    public double getRaggio() {
        return raggio;
    }
}
