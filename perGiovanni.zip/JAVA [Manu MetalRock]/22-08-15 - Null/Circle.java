public class Circle extends DatiCircle {

    public double circonferenza() {
        return 2 * 3.14 * getRaggio();
    }

    public double area() {
        return 3.14 * getRaggio() * getRaggio();
    }

    public double diametro() {
        return getRaggio() * 2;
    }

    public void print () {
        System.out.println("diametro: "+diametro()+"\ncirconferenza: "+circonferenza()+"\narea: "+area());
    }

    public static void main (String[] args) {
        Circle C = new Circle();
        C.setRaggio(20);
        C.print();
    }
}
