class Pet {
    String name;
    String animal;
    int age;

    public void setName (String n)  {
        this.name = n;
    }  
    public void setAnimal (String a) {
        this.animal = a;
    }
    public void setAge (int a) {
        this.age = a;
    }

    public String getName() {
        return name;
    }

    public String getAnimal() {
        return animal;
    }

    public int getAge () {
        return age;
    }
}
public class Classi1 {
    public static void main (String[] args) {
        Pet pet = new Pet();
        pet.setName("Bruno");
        pet.getName();
        System.out.println(pet.getName());
    }
}