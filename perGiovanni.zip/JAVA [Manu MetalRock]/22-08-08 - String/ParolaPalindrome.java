/* Vedere se una parola è palindrome */

import java.util.Scanner;

public class ParolaPalindrome {
    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a word: ");
        String str = in.nextLine();
        boolean palindrome = false;

        for (int i=0; i < str.length()/2; i++) {
            if(str.charAt(i) != str.charAt(str.length()-1-i))
                palindrome = true;
        }
        if (!palindrome)
            System.out.println("La parola è palindrome");
        else
            System.out.println("La parola non è palindrome");
        
        
        in.close();
    }
}

// Funziona solo le le lettere interne delle parole. per esempio Anna funziona n==n, ANna non funziona N==n.
