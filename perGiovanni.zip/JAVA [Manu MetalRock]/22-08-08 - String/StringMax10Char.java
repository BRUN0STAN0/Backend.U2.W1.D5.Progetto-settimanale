/* #String #While
 Input di una parola, controllare se questa parola ha massimo 10 caratteri.
 */
import java.util.Scanner;

public class StringMax10Char {
    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a word: ");
        String str = in.nextLine();
        
        if (str.length() < 10) 
            System.out.println("The word contains less than 10 characters: "+str.length());
        else
            System.out.println("The word contains more than 10 characters: "+str.length());
/* 
        boolean max = false;
        int count = 0;

        while (str.length() < 10 && count<10) {
                max = true;
                count++;
            }
            
        if (!max)
            System.out.println("The word contains more than 10 character.");
        else
            System.out.println("The word containt less than 10 character.");
        */
        in.close();
    }
}
