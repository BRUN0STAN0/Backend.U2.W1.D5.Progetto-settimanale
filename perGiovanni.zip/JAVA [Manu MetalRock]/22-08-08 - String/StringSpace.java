/* #String
Controllare se ci sono spazi " ", eventualmente stamparne la posizione.
 */
import java.util.Scanner;

public class StringSpace {
    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a word: ");
        String str = in.nextLine();

        for (int i = 0; i < str.length(); i++)
            if (str.charAt(i) == ' '){
                System.out.print(i+" ");
            }
        
        /*
        boolean found = false;
        int position = 0;

        for (int i = 0; i < str.length(); i++)
            if (str.charAt(i) == ' '){
                found = true;
                position = i;
            }
                

        if (found){
            System.out.println("There are space in a string.");
            System.out.println("The space is in the position: "+position);
        }
        else
            System.out.println("There aren't space in a string.");
 */
        
        in.close();
    }
}