/* #String
Controllare se ci sono numeri in una stringa
 */
import java.util.Scanner;

public class StringCheckNumber {
    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a word: ");
        String str = in.nextLine();
        boolean found = false;

        for (int i = 0; i < str.length(); i++)
            if (str.charAt(i) >= '0' && str.charAt(i) <= '9')
                found = true;

        if (found)
            System.out.println("There are numbers in a string.");
        else
            System.out.println("There aren't numbers in a string.");
        
        in.close();
    }
}