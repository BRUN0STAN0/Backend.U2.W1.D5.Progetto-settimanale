/* Trovare la lettera specifica in input.
 * 
 */

import java.util.Scanner;

public class Stringa {
    public static void main (String[] args) {
        String string = "abcdefghilmnopqrstuvz";
        Scanner in = new Scanner(System.in);
        System.out.print("Give me a character: ");
        char character = in.next().charAt(0);

        System.out.println(string.indexOf(character));
        
        for (int i=0; i < string.length(); i++)
            if (character == string.charAt(i))
                System.out.println(character+" "+i);


        in.close();
    }
}
