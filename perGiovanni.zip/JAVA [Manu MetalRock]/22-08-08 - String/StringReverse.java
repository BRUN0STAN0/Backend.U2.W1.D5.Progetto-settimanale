public class StringReverse {
    public static void main (String[] args) {
        String string = "abcdefghilmnopqrstuvz";
        String zero = "";

        for (int i = string.length()-1; i >= 0; i--){
            zero += string.charAt(i);
        }
        System.out.print(zero);
    }
}
