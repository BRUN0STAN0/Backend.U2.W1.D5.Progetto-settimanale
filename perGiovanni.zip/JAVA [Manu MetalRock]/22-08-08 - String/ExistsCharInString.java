/* #String
Data la stringa = "sdfsdgadhadhtnjrt", prendere una lettera da input e 
cercare se esiste nella stringa, se esiste ->  assegnare il carattere "0" 
nella posizione della lettera, per poi stampare la stringa nuova. 
 */

import java.util.Scanner;

public class ExistsCharInString {
    public static void main (String[]args) {
        Scanner in = new Scanner(System.in);
        String str = "sdfsdgadhadhtnjrt";
        System.out.print("Give me a letter: ");
        char c = in.next().charAt(0);


        System.out.println(str.replace( c ,'0'));


        in.close();
    }
    
}
