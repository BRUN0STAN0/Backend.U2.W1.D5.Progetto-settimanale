public class overloading {

    static int addition (int a, int b) {
        return a+b;
    }

    public static void main (String[] args) {

        System.out.println(addition(2,3));
        System.out.println(addition(5,3));

    }
}
