import java.util.Scanner;

public class AdditionFunc {

    static int addition(int x, int y) {
        return x+y;    
    }

    static int subtraction (int x, int y) {
        return x-y;
    }
    
    static int multiply (int x, int y) {
        return x*y;
    }

    static int divide(int x, int y) {
        return x/y;
    }

    static int sqrt (int x) {
        int save = 0;
        for (int i = 0; i < x; i++){
            if (i*i==x)
                save = i;
        }
        return save;
    }

    static int square (int x) {
        return x*x;
    }

    static int cube (int x) {
        return x*x*x;
    }
    
    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a value x: "); 
        int x = in.nextInt();
        System.out.print("Insert a value y: "); 
        int y = in.nextInt();
        System.out.println("Which function do you want?");
        System.out.println("Addition \"+\", Subtraction \"-\", Multiply \"*\", Divide \"/\", Sqrt \"%\", Square \"^\" or Cube \"$\"?");
        char input = in.next().charAt(0);


        if (input == '+')
            System.out.println("The result is: "+addition(x,y));
        if (input == '-')
            System.out.println("The result is: "+subtraction(x, y));
        if (input == '*')
            System.out.println("The result is: "+multiply(x, y));
        if (input == '/')
            System.out.println("The result is: "+divide(x,y));
        if (input == '%')
            System.out.println("The result is: "+Math.sqrt(x));
        if (input == '^')
            System.out.println("The result is: "+square(x));
        if (input == '$')
            System.out.println("The result is: "+cube(x));
 
        in.close();
    }
}