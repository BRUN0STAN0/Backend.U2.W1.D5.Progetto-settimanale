import java.util.Scanner;

public class Function {

    static void arrayFunc (int[] array){
        for (int i: array)
            System.out.print(i+" ");
    }

    static void arrayIn (int[] array) {
        Scanner in = new Scanner(System.in);
        for (int i = 0; i < array.length; i++){
            array[i] = in.nextInt();
        } 
        
        in.close();
    }

    public static void main (String[] args){
        Scanner in = new Scanner(System.in);
        int [] array2 = {2,3,4,5,6,7,8};
        arrayFunc(array2);
        System.out.print("\nInsert a value of array: ");
        int index = in.nextInt();
        int [] array3 = new int[index];
        arrayIn(array3);
        arrayFunc(array3);
        in.close();
    }
}
