public class IdentityCard {

    static void personalData(String surname, String name, String placeOfBirth, 
                             String dateOfBirth, String sex, String heightCm, String nationality,
                             String issuing, String expiry) {
        System.out.print("SURNAME:\t"+surname+"\nNAME:\t\t "+name+"\nPLACE OF BIRTH: "+placeOfBirth+
                        "\nDATE OF BIRTH: " +dateOfBirth+"\nSEX:\t\t"+sex+"\nHEIGHT:\t\t "+heightCm+
                        "\nNATIONALITY:\t "+nationality+"\nISSUING:\t"+issuing+"\nEXPIRY:\t\t"+expiry);                            
    }

    public static void main (String[] args) {
        personalData("Stano","Bruno","Brindisi","14.10.94",
                        "Male","173","Italy","07.03.18","14.10.28");
    }
}
