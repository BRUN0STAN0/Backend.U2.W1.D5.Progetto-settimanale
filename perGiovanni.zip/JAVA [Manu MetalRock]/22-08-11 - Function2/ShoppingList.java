import java.util.List;
import java.util.Scanner;

public class ShoppingList {

    static List <String> fishDep(){
        List <String> fish = List.of("Acciughe", "Salmone", "Spigola", "Cefalo", "Dentice",
                                     "Cernia", "Ombrina", "Merluzzo", "Occhiata", "Triglia",
                                     "Sarda", "Spada", "Ricciola");
        return fish;
    }

    static List <String> meatDep(){
        List <String> meat = List.of("Agnello", "Anatra", "Vitello", "Capretto", "Cavallo",
                                     "Coniglio", "Fagiano", "Faraona", "Gallina","Maiale");
        return meat;
    }

    static void cliente(){
        System.out.println("What do you need? Write meat or fish.\n");
        Scanner in = new Scanner(System.in);
        String choise = in.nextLine().toLowerCase();
        if (choise.equals("meat")){
            for (String _meat: meatDep())
                System.out.print(_meat+" ");
        }
        if (choise.equals("fish")){
            for (String _fish: fishDep())
                System.out.print(_fish+" ");
        }
        in.close();
    }

    public static void main (String[] args) {
        cliente();

    }
    
}
