import java.util.*;

public class StudyList {

    public static void main (String[] args) {
        List <Integer> var = new ArrayList<Integer>();

        for (int i=0; i<10; i++)
            var.add(i);
        
        var.add(5, 3);
        
        for (int i: var)
            System.out.print(i+ " ");
        
        System.out.println("\n"+var.size());
    }

}
