public class Function {

    static int[] resizeArray (int[] array) {
        int[] newArray = new int[array.length*2];
        for (int i=0; i < array.length; i++){
            newArray[i] = array[i];
        }
        array = newArray;
        return array;
    }
    public static void main (String[] args) {
        int[] matrice = {0, 1 , 23, 4};
        System.out.println(matrice.length);
        matrice = resizeArray(matrice);
        System.out.println(matrice.length);

    }
}