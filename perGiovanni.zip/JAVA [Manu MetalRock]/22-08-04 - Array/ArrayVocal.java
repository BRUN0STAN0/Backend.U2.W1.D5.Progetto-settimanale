import java.util.Scanner;

public class ArrayVocal {
    public static void main (String[] args) {
    Scanner in = new Scanner(System.in);
        char [] character = new char [10];
        char [] vocal = {'a', 'e', 'i', 'o', 'u'};
        boolean found = false;

        System.out.println("Insert "+character.length+" character.");
        for (int i=0; i < character.length; i++)
            character[i] = in.next().charAt(0);

        /* --------------------------------------------------------------1 METODO
        for (int i=0; i < character.length; i++) {
            if (character[i] == 'a' || character[i] == 'e' || character[i] == 'i'|| character[i] == 'o' || character[i] == 'u')
            found = true;
        }
        */
        /* --------------------------------------------------------------2 METODO */
        for (int i=0; i < character.length; i++) {
            for (int j=0; j < vocal.length; j++) {
                if (character[i] == vocal[j])
                    found = true;
            }
        }

        if (found)
            System.out.println("ERROR");
        else 
            System.out.println("OK");

        in.close();

    }
}