import java.util.Scanner;

public class Esercizio1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int [] array = new int[5];
        boolean found = false;
        
        System.out.print("Insert "+array.length+" integer numbers: ");
        for (int i = 0; i < array.length; i++)
            array[i] = in.nextInt();
    
        for (int i = 0; i < array.length - 1; i++)
            if (array[i] > array[i+1])
                found = true;

                // 2 9 3 2 4


        if (found)
            System.out.println("ORDINE DECRESCENTE O MISTO");
        else
            System.out.println("ORDINE CRESCENTE");

        in.close();
    }
}