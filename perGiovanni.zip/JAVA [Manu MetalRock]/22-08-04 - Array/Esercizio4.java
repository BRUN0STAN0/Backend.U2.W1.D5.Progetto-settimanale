public class Esercizio4 {
    public static void main(String[] args) {
        int[] array = {2, 4, 7, 3, 9};

        System.out.print("Original array: ");
        for (int i = 0; i < array.length; i++)
        System.out.print(array[i]+ " ");
        System.out.println();

        System.out.print("Reverse print: ");
        for (int i = array.length -1; i >= 0; i--)
            System.out.print(array[i]+ " ");
            System.out.println();

        for (int i = 0; i < array.length/2; i++){
            int tmp = array[array.length-1-i];
            array[array.length-1-i] = array[i];
            array[i] = tmp;
        }


        System.out.print("Reverse array: ");
        for (int i = 0; i < array.length; i++)
        System.out.print(array[i]+ " ");
    }
}
