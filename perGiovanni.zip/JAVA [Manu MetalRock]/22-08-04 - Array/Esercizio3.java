import java.util.Scanner;

public class Esercizio3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert the dimension of array: ");
        int x = in.nextInt();
        int [] array = new int[x];
        boolean found = false;

        System.out.print("Insert "+array.length+" numbers: ");
        for (int i = 0; i < array.length; i++)
            array[i] = in.nextInt();

        for (int i = 0; i < array.length - 1; i++){
            for (int j = i+1; j < array.length; j++){
                if (array[i] == array[j])
                    found = true;
            }
        }
        if (found)
            System.out.println(found);
        else 
            System.out.println(found);

        in.close();
    }
}