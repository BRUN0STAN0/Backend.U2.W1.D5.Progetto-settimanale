//ESERCIZIO COPIATO.

public class BubbleSort {
    public static void main(String[] args) {
        int[] array = {2, 4, 7, 3, 5};
        
        for (int i = 0; i < array.length; i++)
            System.out.print(array[i]+" ");

        boolean exchange = false;
        for (int i = array.length - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if (array[j] > array [j+1]) {
                    int tmp = array[j];     // 2 5 3    int tmp = 5
                    array[j] = array[j+1];  // 2 3 3
                    array[j+1] = tmp;       // 2 3 5   
                    exchange = true;        
                }

            }
            if (!exchange)
                break;
        }
        System.out.println();
        for (int i = 0; i < array.length; i++)
            System.out.print(array[i]+" ");
    }
}
