import java.util.Scanner;

public class Array {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int array[] = new int[9];
        System.out.print("Insert an integer number: ");
        int x = in.nextInt();
        boolean found = false;

        System.out.print("Insert "+array.length+" numbers: ");
        for (int i=0; i < array.length; i++)
            array[i] = in.nextInt();

        for (int i=0; i < array.length; i++) {
            if (array[i]%x==0)
                found = true;
        }
        
        if (found) 
            System.out.println("NO. There are elements divisible for "+x);
        else
            System.out.println("OK. No-one elements are divisible for "+x);

        in.close();
    }
}
