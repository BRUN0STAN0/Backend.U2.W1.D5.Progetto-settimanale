import java.util.Scanner;

public class Esercizio2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert the dimension of array: ");
        int x = in.nextInt();
        int [] array = new int[x];
        boolean found = false;
        boolean found2 = false;
        
        System.out.print("Insert "+x+" integer numbers: ");
        for (int i = 0; i < array.length; i++)
            array[i] = in.nextInt();
    
        for (int i = 0; i < array.length - 1; i++)
            if (array[i] < array[i+1])
                found = true;
        

        for (int i = 0; i < array.length - 1; i++)
            if (array[i] > array[i+1])
                found2 = true;
        
        if (found)
            System.out.println("ORDINE CRESCENTE");

        if (found2)
            System.out.println("ORDINE DECRESCENTE");
        
        if (found && found2)
            System.out.println("ORDINE MISTO");

        in.close();
    }
}