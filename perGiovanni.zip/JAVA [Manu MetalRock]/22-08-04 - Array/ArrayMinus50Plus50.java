import java.util.Scanner;

public class ArrayMinus50Plus50 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int [] array = new int [10];
        boolean found = false;
        int outOfRange = 0;
        int count = 0;

        System.out.println("Insert "+array.length+" integer numbers.");

        for (int i = 0; i < array.length; i++)
            array[i] = in.nextInt();
        
        for (int i = 0; i < array.length; i++)
            if (array[i] < -50 || array[i] > 50) {
                found = true;
                System.out.print(array[i]+" ");
                outOfRange += array[i];
                count++;
            }

        if (!found)
            System.out.println("VUOTO1");
            
        outOfRange /= count;
        System.out.println(outOfRange);
        in.close();
    }
}