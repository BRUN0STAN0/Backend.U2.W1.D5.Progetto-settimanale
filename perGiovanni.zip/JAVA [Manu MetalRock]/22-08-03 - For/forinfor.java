import java.util.Scanner;

public class forinfor {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a positive number: ");
        int x = in.nextInt();

        for (int rows = 0; rows < x; rows++)
            System.out.print(rows);
        System.out.println();
        for (int cols = 1; cols < x; cols++)
            System.out.println(cols);

        
        in.close();
    }
    
}