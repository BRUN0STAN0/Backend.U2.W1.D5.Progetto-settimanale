public class PrimeNumber {
    public static void main(String[] args) {

        for(int number = 0; number <= 100; number++) {
            int found = 0;
            for (int denominator = 1; denominator <= number; denominator++) {
                if (number % denominator == 0)
                    found++;
                }
            if (found == 2 ) {
                System.out.print(number+" ");
            }
            
        }
    }    
}