import java.util.Scanner;

public class StampNumberOfAsterisk {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a positive number: ");
        int x = in.nextInt();

        for (int rows = 0; rows < x; rows++){
            for (int cols = 0; cols < x - rows ; cols++)
                System.out.print("*");
            System.out.println();
        }
        in.close();
    }
    
}
