import java.util.Scanner;

public class InvertNumber {
    public static void main (String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a sequence of number:\t");
        int reverse = 0; 

        for(int number = in.nextInt(); number != 0; number=number/10) {  
            int remainder = number % 10;  
            reverse = reverse * 10 + remainder;  
        }  
        System.out.print("The reverse sequence number is:\t" + reverse); 
         
        in.close();
    }  
}  