import java.util.Scanner;

public class SequenceNumber {
    public static void main (String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Insert a sequence of character:");
        char character = in.next().charAt(0);
        boolean found = false;

        
        while(character != '*') {
            if (character >= '0' && character <= '9')
                found = true;
                character = in.next().charAt(0);
        }

        if (found)
        System.out.println("ALMENO UNA");
        else
        System.out.println("NESSUNA");

        in.close();
    } 
}
