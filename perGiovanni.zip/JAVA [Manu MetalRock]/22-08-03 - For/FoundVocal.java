import java.util.Scanner;

public class FoundVocal {
    public static void main (String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Insert a sequence of character:");
        char vocal = in.next().charAt(0);
        boolean found = false;

        while (vocal != '*'){
            if (vocal == 'a' || vocal == 'e' || vocal == 'i' || vocal ==  'o' || vocal ==  'u')
                found = true;
                vocal = in.next().charAt(0);
        }
        
        if (found)
            System.out.println("ALMENO 1 VOCALE MINUSCOLA");
        else
            System.out.println("NESSUNA VOCALE");

        in.close();
    } 
}
