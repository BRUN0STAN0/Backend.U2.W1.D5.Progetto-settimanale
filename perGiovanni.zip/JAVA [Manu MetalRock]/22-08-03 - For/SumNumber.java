public class SumNumber {
    
    public static void main(String[] args) {
        int lastNumber = 0;

        for (int i=0; i<=100; i++){
             lastNumber += i;
             System.out.println(lastNumber);
        }

        

  }
}