package Exsercise;


public class Exsercise1 {
    public static void main(String[] args) {
        int value = 3;
        System.out.printf("Integer value with percentage f: ");
        System.out.printf("Integer value with percentage d: %d", value);
    }
}
