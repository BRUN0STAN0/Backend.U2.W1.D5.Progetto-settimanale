package Exsercise;

import java.util.*;

public class Exsercise3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a second to convert: ");
        int totsecond = in.nextInt();

        int hour = totsecond / 3600;
        int minute = (totsecond % 3600) / 60;
        int second = (totsecond % 3600) % 60;

        System.out.println(totsecond+" seconds = "+hour+" hours, "+minute+" minutes, and "+second+" seconds");

        in.close();
    }
    
}
