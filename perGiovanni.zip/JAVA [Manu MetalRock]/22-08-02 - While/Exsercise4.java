package Exsercise;

import java.util.*;

public class Exsercise4 {
    public static void main (String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("I'm thinking of a number between 1 and 100");
        System.out.println("(including both). Can you guess what it is?");
        System.out.print("Type a number: ");
        int number = in.nextInt();
        System.out.println("Your guess is: "+number);
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1;
        if (number > 100 || number < 0)
            System.out.println("ERROR: The number is incorrect.");
        else if (randomNumber != number){
            System.out.println("The number i was thinking of is: "+randomNumber);
            System.out.println("You were off by: "+(number-randomNumber));
        }
        else
            System.out.println("Congratulation! You got the number!");
        in.close();
    }
    
}
