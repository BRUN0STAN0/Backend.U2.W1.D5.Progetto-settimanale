import java.util.Scanner;

public class MultipleNumber {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Insert the first number: ");
        int firstNumber = in.nextInt();
        System.out.print("Insert the second number: ");
        int secondNumber = in.nextInt();

        if (firstNumber%secondNumber == 0)
        System.out.println("It's multiple.");
        else
        System.out.println("It'not a multiple.");

        in.close();
    }
    
}
