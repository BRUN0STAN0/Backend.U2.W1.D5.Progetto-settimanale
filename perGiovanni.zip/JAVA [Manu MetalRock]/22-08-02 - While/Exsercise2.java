package Exsercise;

import java.util.Scanner;

public class Exsercise2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insert a Celsius temperature: ");
        double celsius = in.nextDouble();
        double Fahrenheit = celsius * 9/5 + 32;

        System.out.println(celsius+" C = "+Fahrenheit+" F");

        in.close();
    }
}
