import java.util.Scanner;

public class HowManyZero {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("How many 0 do you want check? ");
        int X = in.nextInt();
        System.out.println("Give me a sequence which ends with \"-1\": ");
        int sequence = in.nextInt();
        int consecutive = 0;
        int saveZero = 0;

        while (sequence != -1){
            if (sequence == 0){
                consecutive++;
                if (consecutive <= X)
                    saveZero++;
            }
                
            sequence = in.nextInt();
        }
        
        if (saveZero == X)
        System.out.printf("Ok. There are %d ore more zero consecutive in sequence and you want check X=%d consecutive zero", saveZero, X);
        else
        System.out.printf("No. You have insert in a sequence %d consecutive zero, but you want check X=%d consecutive zero.", saveZero, X);

        in.close();
    }
}
