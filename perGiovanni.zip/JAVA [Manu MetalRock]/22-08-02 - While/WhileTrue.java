import java.util.Scanner;

public class WhileTrue{
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int N = 0;
/* 
        while(true){
            N++;
            if(N == 120)
                break;
            System.out.println(N);
        }*/

        while (N != 120){
            System.out.println(N);
            N++;
        }

        in.close();
    }
}