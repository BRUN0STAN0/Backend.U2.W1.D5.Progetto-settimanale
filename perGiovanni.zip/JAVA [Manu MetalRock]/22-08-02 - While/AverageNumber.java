import java.util.Scanner;

public class AverageNumber {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Insert an integer number: ");
        int number = in.nextInt();
        int count = 0;
        int result = 0;

        while (number != -1) {
            result += number;
            count++;
            System.out.println("Media: "+( (double) result/count));
            System.out.print("Insert an integer number: ");
            number = in.nextInt();
        }

        in.close();
    }
}