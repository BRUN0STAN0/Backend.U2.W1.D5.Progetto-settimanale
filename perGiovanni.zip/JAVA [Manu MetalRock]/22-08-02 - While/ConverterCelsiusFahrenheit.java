import java.util.Scanner;


public class ConverterCelsiusFahrenheit {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Insert the temperature in Celsius: \t");
        double celsius = in.nextDouble();
        final double CELSIUS_TO_FAHRENHEIT = (9.0/5.0) * celsius + 32;
        final double CELSIUS_TO_KELVIN = celsius + 273.15;
        double kelvin = CELSIUS_TO_KELVIN;
    
        if (kelvin < 0) // Lo zero assoluto corrisponde a 0 Kelvin.
            System.out.println("ERROR: Absolute zero is unattainable due to the third law of thermodynamics.\n");
        else {
            System.out.println("The Fahrenheit temperature is: \t\t"+CELSIUS_TO_FAHRENHEIT);
            System.out.println("The Kelvin themperature is: \t\t"+CELSIUS_TO_KELVIN);
        }

        in.close();
    }
    
}