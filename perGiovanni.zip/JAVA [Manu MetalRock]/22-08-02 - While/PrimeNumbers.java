import java.util.Scanner;
public class PrimeNumbers {

    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        
        System.out.print("Please insert an integer number: ");
        int number = in.nextInt();
        int base = 1;
        int count = 0;

        while(base <= number){
            if(number % base == 0)
                count++;
            base++;
        }

        if (count == 1 || count > 2)
            System.out.println("It's not a Prime Number.");
        else
            System.out.println("It's a Prime Number.");

        in.close();
    }
}
