import java.util.Scanner;

public class WhileTrueCopy{
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        int count = 0;

        while(true){
            if(N%2==0){
                System.out.println(N);
                break;
            }
            else {
                N = in.nextInt();
                count++;
            }
        }
        System.out.println("Number of failed attempts: "+count);


        in.close();
    }
}