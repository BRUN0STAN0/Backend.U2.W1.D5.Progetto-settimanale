import java.util.Scanner;

class Calcolatrice {
    private double a, b;

    public void setAB(double n1, double n2) {
        this.a = n1;
        this.b = n2;
    }

    public double sum(){
        return a+b;
    }

    public double multiply(){
        return a*b;
    }

    public double division(){
        return a/b;
    }

    public double subtraction() {
        return a-b;
    }
}


public class Calculator {

    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        Calcolatrice cal = new Calcolatrice();
        System.out.print("Insert a value of \"a\":");
        double a = in.nextDouble();
        System.out.print("Insert a value of \"b\":");
        double b = in.nextDouble();
        
        cal.setAB(a, b);
        System.out.println(cal.sum());
        
        in.close();
    }
    
}
