import java.util.Scanner;

public class Array {

    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Give me the limit of elements in array: ");
        int limitArray = in.nextInt();
        int[] array = new int[limitArray];

        for (int number = 0; number < limitArray; number++) {
            array[number] = in.nextInt();
        }

        for (int i= 0; i < limitArray; i++) {
            if (array[i]%2==0 && i%2 == 0){
                System.out.print(array[i]+" ");
            }
            if (array[i]%2!=0 && i%2 != 0)
                System.out.print(array[i]+" ");
        }
        
        in.close();
    }
    
}
