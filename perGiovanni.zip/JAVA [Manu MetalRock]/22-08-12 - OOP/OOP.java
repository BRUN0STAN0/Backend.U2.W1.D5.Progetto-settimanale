 class Main {
    protected String name;
    protected String surname;
    protected int id;

    protected String getName() {
        return name;
    } 
    protected String getSurname() {
        return surname;
    } 
    protected int getId() {
        return id;
    }

    protected void setName(String n) {
        this.name = n;
    } 
    protected void setSurname(String s) {
        this.surname = s;
    } 
    protected void setId (int i) {
        this.id = i;
    }
}

public class OOP {
        public static void main(String[] args) {
            Main obj = new Main();

            obj.setName("Bruno");
            obj.setSurname("Stano");
            obj.setId(10);
            System.out.println(obj.getName()+obj.getSurname()+obj.getId());

        }
    }
