 public class ForEach{
    public static void main(String[] args) {
        String [] str = {"ciao", "io", "sono", "Bruno"};


        //for each;
        for (String i: str)
            System.out.print(i+" ");

        System.out.println();

        //for
        for (int i = 0; i < str.length; i++)
            System.out.print(str[i]+" ");
    }
 }