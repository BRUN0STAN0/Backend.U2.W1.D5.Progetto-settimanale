public class ForEach2{
    public static void main(String[] args) {
        int[] array = {8,9,10,5,2,1};
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        for (int i: array) {
            if (i > max)
            max = i;
            if (i < min)
            min = i;
        }
        System.out.println(max);

        System.out.println(min);
    }
 }