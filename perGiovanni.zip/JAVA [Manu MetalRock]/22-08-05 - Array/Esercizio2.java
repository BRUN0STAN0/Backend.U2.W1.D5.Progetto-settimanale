public class Esercizio2 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 1, 2, 3};

        for (int i=0; i < array.length-1; i++) {
            for (int j=i+1; j < array.length; j++){
                if (array[i] == array[j])
                    System.out.println(i+" "+j);
            }
        }
    }
}