/*Dato un array di interi, stampare la posizione iniziale e finale di una serie di numeri crescenti.
Es:
{ 1 2 3 4 1 2 3}
Stampa: Pos 0(1) Pos 3 (4) */
public class Esercizio1 {
    public static void main(String[] args) {
    int[] array = {3,2,3,4,5,2,1};

/* 
        int save = 0;
        int save2 = 0;

        for (int i=0; i < array.length-1; i++){
            if (array[i] < array[i+1])
                save = array[i+1];
            if (array[array.length-1-i] < array[array.length-2-i]) 
                save2 = array[array.length-1-i];
        }
        System.out.println(save);
        System.out.println(save2);
*/
     
        int minorP = -1;
        int minorV = 0;
        int greaterP = 0;
        int greaterV = 0;
        
        for (int i = 0; i < array.length-1; i++) {
            if (array[i] < array[i+1] && minorP == -1){
                minorP = i;
                minorV = array[i];
            }
                
            if (array[i] > array[i+1] && greaterP == 0){
                greaterP = i;
                greaterV = array[i];
            }
        }
        
        System.out.println("Pos: "+minorP+" ("+minorV+")");
        System.out.println("Pos: "+greaterP+" ("+greaterV+")");


    }
}


