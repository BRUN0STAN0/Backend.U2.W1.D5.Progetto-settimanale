public class Array2D {
    public static void main(String[] args) {

        String[][] classroom = new String [3][3];

        classroom[0][0] = "Lucarello";
        classroom[0][1] = "Annamaria";
        classroom[0][2] = "Marco";

        classroom[1][0] = "Edoardo";
        classroom[1][1] = "Leonardo";
        classroom[1][2] = "Antonio";

        classroom[2][0] = "Arianna";
        classroom[2][1] = "Paolo";
        classroom[2][2] = "Andrea";

        for (int room = 0; room < classroom.length; room++) {
            for(int student = 0; student < classroom.length; student++)
                System.out.print(classroom[room][student]+" \t ");
            System.out.println();
        }
    }
}