public class Array2DForEach {
    public static void main(String[] args) {
        String[][] classroom = { 
                                    {"Luca", "Anna", "Marco"}, 
                                    {"Edoardo", "Roberto", "Mario"}, 
                                    {"Teodoro", "Bruno", "Lino"}
                               };

        for (String[] room: classroom) {
            for(String student: room)
                System.out.print(student + "\t");
            System.out.println();
        }
    }
    
}
