package Exercises;

public class apples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
