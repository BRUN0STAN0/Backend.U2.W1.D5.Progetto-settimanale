package Tests;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Size {

	public static void main(String[] args) {
		int[] counts = {1,2,3,4,5,6};
		
		
		
		for (int i = 0; i < 6; i++) {
			System.out.println(counts[i]);
		}
		
		
		
		
		

	}

}
