
public class IntroToPolymorphism55 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static void helloWorld(String[] args) {
		System.out.println("Hello world");
	}

}
