import java.util.Scanner;

public class apples {

	public static void main(String[] args) {
		
		tuna tunaObject = new tuna();
		System.out.println(tunaObject.toMilitary());
		System.out.println(tunaObject.toString());
		
		tunaObject.setTime(8, 36, 24);
		System.out.println(tunaObject.toString());
		
		System.out.println(8%12);
	}
		
	

}
