/**
 * Exercise 2-3.4 of Think Java, 2016.
 * 
 * @author Quan Truong
 *
 */

/**
 * 3. Make the program calculate and display the number of seconds since midnight.
 */
public class SecondsSinceMidnight {
	
	public static void main(String[] args) {
		int hour, minute, second;
		hour = 14;
		minute = 0;
		second = 0;
		int midnight = ( (hour * 60) * 60 ) + (minute * 60) + second; 
		System.out.println(midnight);
		
	}

}
