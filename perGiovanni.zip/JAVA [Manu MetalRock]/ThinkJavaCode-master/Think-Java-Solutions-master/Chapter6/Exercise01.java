/**
 * Exercise 6-1 of Think Java, 2016.
 * 
 * @author Quan Truong
 *
 */
public class Exercise01 {

	public static void main(String[] args) {
		int unusedVariable; //variable is not used, compiler returns error of "local variable unusedVariable is not used"
		
		System.out.println("boo") + 7; //compiler returns the left hand side must be a variable
		

	}

}
