
/**
 * Calculates the area of a circle
 * @author qmtru
 *
 */

public class ReturnValues {

	public static double calculateArea(double radius) {
		return Math.PI * radius * radius;
	}
}
