
public class HelloWorld {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		int hour = 11;
//		int minute = 59;
//		System.out.print("The current time is ");
//		System.out.print(hour);
//		System.out.print(":");
//		System.out.print(minute);
//		System.out.println(".");
////		System.out.println("The current time is ");
////		System.out.print(hour + ":" + min);

//	}
	
	/*
//Two methods inside the same class is not working. 
	public static void main(String[] args) {
	    int hour1 = 11;
	    double minute1 = 59.0;
	    double pi = 3.143223;
	    double y = 1 /3;
	    System.out.print("The number of minutes since midnight ");
	    System.out.println(minute1 / 60);
	    System.out.print("The number pi / 60 is ");
	    System.out.println(pi / 60);
	    System.out.println(y * 3);
	}

}

*/
	
//	public static void main(String[] args) {
//		//Convert int 12451 to display as string "$125.41"
//		int cents = 12451;
//		double dollars = 100;
//		System.out.print("The amount of money in your account is ");
//		System.out.println(cents / dollars + ".");
//	}
	
	public static void main(String[] args) {
	     double minutes = 59;
	     double percentage = (minutes * 100) / 60;
	     System.out.println(percentage);  
	  }
	
}
