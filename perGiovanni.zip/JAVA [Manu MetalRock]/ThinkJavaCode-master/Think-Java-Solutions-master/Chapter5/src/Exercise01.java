/**
 * Exercise 5-2 of Think Java, 2016.
 * 
 * @author Quan Truong
 *
 */
public class Exercise01 {

	public static void main(String[] args) {
		int x = 6;
		
		if (x > 0 && x < 10) {
			System.out.println("positive single digit integer");
		}

	}

}
