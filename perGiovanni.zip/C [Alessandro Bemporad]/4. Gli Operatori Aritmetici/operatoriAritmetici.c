#include <stdio.h>
int main(){
    int x = 5 + 10 / 2 * 5;
    printf ("X vale = %d\n", x);
    int intero = 7.0/3;
    printf ("intero di 7/3 = %d\n", intero);
    float doppio = 7.0/3.0;
    printf ("float di 7/3 = %f\n", doppio);
    int resto = 7%3;+
    printf ("Resto di 7/3 = %i\n", resto);
    int y = 10;
    int preincremento = ++y;
    printf ("Incremento di ++10 = %i\n", preincremento);
    int postincremento = y++;
    printf ("PostIncremento di 10++ = %i\n", postincremento);
    return 0;
}