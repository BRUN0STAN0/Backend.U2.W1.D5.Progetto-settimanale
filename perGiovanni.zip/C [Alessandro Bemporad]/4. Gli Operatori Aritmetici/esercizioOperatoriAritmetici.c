#include <stdio.h>
int main(){
    int x = 10;
    ++x;
    int m = x % 2;
    printf ("Il risultato di 10 + 1 = 11 / 2 = il resto? %d\n", m);
    return 0;
}