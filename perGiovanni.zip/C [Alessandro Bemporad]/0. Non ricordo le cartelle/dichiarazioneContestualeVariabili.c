#include <stdio.h>
int main(){
    struct {
        short red;
        short green;
        short blue;
    } c1 = {12,180,200},
      c2 = {40,80,75};
      return 0;
}