#include <stdio.h>
#include <string.h>
int main(){
    char parola[] = {'C','i','a','o','\0'};
    printf("%s\n", parola);
    char parola2[] = "Ciao \"Amico\"";
    printf("%s\n", parola2);
    
    /* Questo è una simulazione di un errore.

    char parola3[10];
    parola3 = "ciaoiosono";
    printf("%s\n", parola3);
    
    */
    char parola3[10];
    strcpy(parola,"Ciao ho copiato una stringa, grazie all'inclusione della string.h");
    printf("%s\n", parola);
    return 0;
}