#include <stdio.h>
int main(){
    int x = 10;
    int y = 20;
    int z = 5;
    x = x * y + z;
    printf("10 * 20 + 5 = %i\n",x);
    int a = 10;
    int b = 20;
    int c = 5;
    a *= b + c;
    printf("10 * (20 + 5) = %i\n", a);
    return 0;
}