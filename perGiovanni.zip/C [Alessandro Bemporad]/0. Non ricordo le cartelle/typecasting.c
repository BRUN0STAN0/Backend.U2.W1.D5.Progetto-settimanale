#include <stdio.h>
int main(){
    int x = 20, y = 6;
    double d = (double) x / y;
    printf("%f", d);
    return 0;
}