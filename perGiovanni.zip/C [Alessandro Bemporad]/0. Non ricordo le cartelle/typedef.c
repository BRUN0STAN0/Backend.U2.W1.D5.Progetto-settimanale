#include <stdio.h>
int main(){
    typedef double doppio;

    doppio x = 75.3;
    printf ("%f", x);

    return 0;
}