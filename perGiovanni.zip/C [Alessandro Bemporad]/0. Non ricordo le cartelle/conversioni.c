#include <stdio.h>
int main(){
    int x = 10;

    // Una conversione fatta bene.
    int y = x;
    printf ("int y = x; %d\n", y);

    // Da 10, si aggiungono valori dopo la virgola, diventa piu preciso.
    float z = x;
    printf ("float z = x; %f\n", z);

    // Da 10.5 si perde il valore dopo la virgola, da float ad int.
    float f = 10.5;
    int i = f;
    printf ("int i = f; %d\n", i);

    // I Valori per un UNSIGNED CHAR sono 256 - Quindi il pc arriva a 256, poi per arrivare a 300 ne mancano 44 e ti segna 44. Quindi si perde il calcolo
    int trecento = 300;
    unsigned char senzasegno = trecento;
    printf ("unsigned char senzasegno = trecento; %d\n", senzasegno);

    // Qui da 300 si passa al valore 1, perche il valore è diverso da 0 !=0
    _Bool boolean = trecento;
    printf ("_Bool Boolean = trecento; %d\n", boolean);
}