#include <stdio.h>
int main(){
    int larger(int x, int y){
        printf("Dammi un numero intero per x: ");
        scanf("%i",&x);
        printf("Dammi un numero intero per y: ");
        scanf("%i",&y);        
        return x > y? x : y;
    }
    return 0;
}