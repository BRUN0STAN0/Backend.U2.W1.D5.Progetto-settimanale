#include <stdio.h>
int somma_global(int x, int y);

int global = 20;

int main(){
    int a = 5, b = 10;
    int c = somma(a,b);
    printf("c: %d\n", c);
    return 0;
}

int somma_global (int x, int y){
    return x + y + global ;
}