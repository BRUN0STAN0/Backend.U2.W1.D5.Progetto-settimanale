#include <stdio.h>

main() {
	int intero;
	float virgola;
	char c;
	
	printf("\nInserisci un carattere: ");
	scanf("%c", &c);
	printf("Carattere: %c", c);
	
	printf("\nInserisci un numero intero: ");
	scanf("%d", &intero);
	printf("Intero: %d", intero);

	printf("\nInserisci un numero con la virgola: ");	
	scanf("%f", &virgola);
	printf("Numero con la virgola: %5.2f", virgola);

}