#include <stdio.h>

int somma (int a, int b);
int sottrazione (int a, int b);

int main (){
    char operazione;
    int x, y;
    int risultato;

    printf("Inserisci il valore di x\n");
    scanf("%i",&x);    
    printf("Inserisci il valore di y\n");
    scanf("%i",&y);    
    printf("Inserisci + o -\n");
    scanf("%c", operazione);

    switch (operazione) {
        case '+':
            risultato = somma(x,y);
            printf("%d\n",risultato);
            break;
        case '-':
            risultato = sottrazione(x,y);
            printf("%d\n",risultato);
            break;
        default:
            printf("Operazione errata\n");
    }

    return 0;
}

int somma (int a, int b){
    return a + b;
}

int sottrazione (int a, int b){
    return a - b;
}