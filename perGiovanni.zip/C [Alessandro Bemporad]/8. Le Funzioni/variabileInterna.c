#include <stdio.h>
int main(){
    int a = 5, b = 10;
    int c = somma(a,b);
    printf("c: %d\n", c);
    return 0;
}

int somma (int x, int y){
    int z;
    z = x + y;
    printf("z: %d\n", z);
    return z;
}