#include <stdio.h>

int glob = 150;

int main(){

    printf("%d\n",glob); // 150

    int glob = 200;
    printf("%d\n",glob); //200

    if (glob == 200){
        int glob = 500;
        printf("%d\n", glob); //500 
    }

    printf("%d\n", glob); //200
    return 0;
}