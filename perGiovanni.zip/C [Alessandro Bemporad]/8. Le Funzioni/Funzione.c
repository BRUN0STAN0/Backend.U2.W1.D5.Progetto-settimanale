#include <stdio.h>
// PROTOTIPO DELLA FUNZIONE SOMMA
int somma(int x, int y);

// Funzione Principale
int main(){
    int a = somma (5, 10);
    printf("a: %d\n", a);
    return 0;
}

// Funzione Somma
int somma(int x, int y){
    return x + y;
}