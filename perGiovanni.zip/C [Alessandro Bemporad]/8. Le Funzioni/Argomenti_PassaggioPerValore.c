#include <stdio.h>{
    int azzera (int x, int y);

    int main(void){
        int a= 5, b = 10;
        azzera(a,b);
        printf("a: %d b: %d\n", a, b);
        return 0;
    }
    int azzera (int x, int y){
        x = 0;
        y = 0;
    }
}