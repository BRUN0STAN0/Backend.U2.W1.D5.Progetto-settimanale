#include <stdio.h>
int main(){
    //                  1
    int arr1[5] = {'a','b','c','d','e'};
    //                      2
    int arr2[6] = {'f','g','h','i','l'};
    arr2[2] = arr1[1];
    // Visualizza sul terminale il valore del terzo elemento del vettore arr2.
    printf("%c",arr2[2]);
    return 0;
}