#include <stdio.h>
int main(){
    int x = 0;
    int array[x];
    array[3] = 50;
    printf("%d", array[3]);
}