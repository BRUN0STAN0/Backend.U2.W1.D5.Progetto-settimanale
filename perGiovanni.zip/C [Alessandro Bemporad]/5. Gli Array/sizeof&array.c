#include <stdio.h>
int main(){
    int array[5][3];
    printf("Numero di Byte nell'array: %d\n",sizeof(array)/sizeof(int));
    printf("Numero di elementi dell'array:%d\n",sizeof(array));
}