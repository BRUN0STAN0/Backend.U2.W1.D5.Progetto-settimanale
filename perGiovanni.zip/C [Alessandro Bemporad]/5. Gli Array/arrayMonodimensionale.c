#include <stdio.h>
int main(){
    //                     0    1   2   3   4   5
    int giorni_mese[12] = {31, 28, 31, 30, 31, 30, 30, 31, 31, 30, 31, 30, 31};
    int x = 5;
    int y = giorni_mese[x];
    printf("%d\n", y);
    y = giorni_mese[0];
    printf("%d\n", y);
    return 0;
}