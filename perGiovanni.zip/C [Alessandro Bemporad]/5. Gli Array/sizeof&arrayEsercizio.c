#include <stdio.h>
int main(){
    double arrd[3] = {1.2, 2.3, 3.1};
    printf("%d\n",sizeof(double));
    printf("%d\n",sizeof(arrd));
    printf("%d\n",sizeof(arrd)/sizeof(double));
}