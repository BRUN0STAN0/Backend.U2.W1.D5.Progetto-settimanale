#include <stdio.h>
#include <stdlib.h> //qui dentro c'è la funzione malloc
#include <string.h> //qui dentro c'è la funzione strcpy

int main(){
    char *p = (char *) malloc(5);
    if (p) {
        strcpy(p,"Ciao");
        printf("%s\n", p);
        free(p);
    }
    return 0;
}