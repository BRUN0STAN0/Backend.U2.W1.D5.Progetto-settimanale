#include <stdio.h>
#include <string.h>
int main(){

    int ncap = 2;

    typedef struct{
        char titolo[50];
        char autore[50];
    } Intestazione;

    typedef struct {
        char titolo[50];
        int numero_pagine;
    } Capitolo;

    typedef struct {
        Intestazione intestazione;
        Capitolo capitoli[ncap];
    } Libro;

    Libro libro;
    strcpy(libro.intestazione.titolo,"Le mie memorie");
    strcpy(libro.intestazione.autore,"Bruno Stano");

    strcpy(libro.capitoli[0].titolo,"Prefazione");
    libro.capitoli[0].numero_pagine = 100;

    strcpy(libro.capitoli[1].titolo,"Capitolo 1");
    libro.capitoli[1].numero_pagine = 50;

    printf("%s\n",libro.intestazione.autore);
    printf("%d\n",libro.capitoli[1].numero_pagine);
    return 0;
}