#include <stdio.h>
int main(){
    enum punticardinali {NORD, SUD, EST, OVEST} p1;
    p1 = OVEST;
    printf("%d", p1);
    return 0;
}