#include <stdio.h>
int main(){
    union Unione {
        short s;
        double d;
        char c;
    };
    union unione u;
    u.s = 120;
    u.c = "B"
}