#include <stdio.h>
int main(){
    struct rgb_color
    {
        short [3];
        float alpha;
    };

    struct rgb_color c1;
    c1.color[0] = 115;
    c1.color[1] = 181;
    c1.color[2] = 40;
    c1.alpha = 1.0f;
    //oppure
    struct rgb_color c1 = {115,181,40},1.0f;
    return 0;
}