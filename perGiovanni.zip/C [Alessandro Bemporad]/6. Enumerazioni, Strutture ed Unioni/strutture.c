#include <stdio.h>
int main(){
    //Rappresentazione colore RGB tramite struttura
    struct rgb_color {
        short red;
        short green;
        short blue;
    };
    //Inizializazzione del colore verde
    struct rgb_color c1 = {.red=115, .green=181, .blue=40};

    //Diminuisco la quantita di verde, e il colore diventa rosso scuro
    c1.green = 20;
}