#include <stdio.h>

int incrementa();
int incrementa2();

int main(){

    int a;

    for (int i = 0; i < 5; i++) {
        a = incrementa();
        printf("%d ",a);
    }

    printf ("\n");

    for (int i = 0; i < 5; i++) {
        a = incrementa2();
        printf("%d ",a);
    }
    return 0;
}

int incrementa() {
    int x = 0;
    x += 1;
    return x;
}

int incrementa2() {
    static x = 0;
    x += 1;
    return x;
}