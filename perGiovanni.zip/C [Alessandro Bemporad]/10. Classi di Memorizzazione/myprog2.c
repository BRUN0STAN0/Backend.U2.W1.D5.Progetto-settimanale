#include <stdio.h>
int main(){
    extern int somma(int x, int y){
        return x + y;
    }
}