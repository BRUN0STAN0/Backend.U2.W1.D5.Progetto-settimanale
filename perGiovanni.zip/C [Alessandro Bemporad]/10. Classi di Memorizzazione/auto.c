#include <stdio.h>
int main(){
    auto int x = 50;
    printf("%d\n", x);
    return 0;
}