#include <stdio.h>
int main(){
    int *myptr;
    int my_var = 180;
    my_ptr = &my_var;
    printf("%d\n", myptr); //9472
    printf("%d\n", *myptr); //180
    return 0;
}