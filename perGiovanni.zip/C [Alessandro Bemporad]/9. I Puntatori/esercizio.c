#include <stdio.h>
int main(){
    int array[] = {0,1,2,3,4,5,6,7,8,9};
    int *myptr;
    int lunghezza = sizeof(array)/sizeof(int);

    myptr = &array[0];

    for (int i = 0; i < lunghezza; i++)
        printf("%d %d\n",*(myptr + i), *(myptr + (lunghezza -1) - i));

    return 0;
}