#include <stdio.h>
int main (){
    int x = 10;
    int *ptr1;
    int **ptr2;

    ptr1 = &x;
    ptr2 = &ptr1;

    printf("%d\n",x); //10
    printf("%d\n",*ptr1); //10
    printf("%d\n",ptr1); //642296
    printf("%d\n",ptr2); //642292
    printf("%d\n",*ptr2); //642296
    printf("%d\n",**ptr2); // 10
}