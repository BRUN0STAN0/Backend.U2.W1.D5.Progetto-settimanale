#include <stdio.h>
int main(){
    int *ptr[] = {
        (int []) {4,60,6},
        (int []) {70,5,12,34},
        (int []) {1,95}
    };

    printf("%d\n",ptr);
    printf("%d\n",&ptr[0]);
    printf("%d\n",*ptr[0]);
    printf("%d\n",*ptr[2]);
    printf("%d\n",ptr[0][1]);
    printf("%d\n",ptr[1][2]);
    return 0;
}