#include <stdio.h>
int main(){
    int a = 10;
    int *my_ptr = &a;
    modifica(my_ptr);
    printf("%d\n", a); // 20
    return 0;
}

void modifica(int *x){
    *x = *x + *x; // 10 + 10
}