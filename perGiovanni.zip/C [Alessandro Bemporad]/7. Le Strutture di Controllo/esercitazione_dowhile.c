#include <stdio.h>
int main(){
    int array[] = {1, 3, 5, 6, 7};
    int i = 0;
    _Bool found = 0;

    do
    {
        if (array[i] % 2 == 0){
            found = 1;
            break;
        }
    } while (++i < sizeof(array) / sizeof(int));
    
    if (found != 0)
        printf("%d\n", array[i]);
    else
        printf("Numero dispari \n");

    return 0;
}