#include <stdio.h>
int main(){
    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10; j++){
            if (i == 5 || j == 5)
                goto uscita;
            printf("%d %d\n", i, j);
        }
    }
    uscita:
    return 0;
}