#include <stdio.h>
int main(){
    printf("WHILE\n");
    int i = 0;
    while (i < 10){
        printf("%d\n",i);
        ++i;
    }

    printf("FOR\n");
    for (int j = 0; j < 10; j++)
    {
        printf("%d\n",j);
    }
    // IL DO WHILE fa almeno una stampa e poi controlla.
    printf("DO WHILE\n");
    int x = 100;
    do {
        printf("%d\n", x);
        ++x;
    }    while (x < 10);

    return 0;
}