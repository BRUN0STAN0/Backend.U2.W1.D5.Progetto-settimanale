#include <stdio.h>
int main(){
    // Non è un'espressione booleana ma è un espressione che deve ritornare un valore intero
    int x = 2;
    switch (x) {
        case 0:
            break;
        case 1:
            printf("x vale 1\n");
            break;
        case 2:
            printf("x vale 2\n");
            break;
        default:
            printf("x non è valido\n");
            break;
    }
    return 0;
}