#include <stdio.h>
int main(){
    /*
    == Uguale
    != Diverso
    > Maggiore
    >= Maggiore Uguale
    < Minore
    <= Minore Uguale
    */

    // Statement IF
    int x = 10;
    int y = 10;
    if (x == y)
        printf("x e y sono uguali\n");
    else
        printf("x e y sono diversi\n");

    // check valore di 11
    int z = 11;
    if (z == 9)
        printf("z vale 9\n");
    else if (z == 10)
        printf("z vale 10\n");
    else if (z == 11)
        printf("z vale 11\n");
    else
        printf("z non e' valido\n");

    return 0;

}