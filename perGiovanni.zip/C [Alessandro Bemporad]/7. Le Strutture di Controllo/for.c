#include <stdio.h>
int main(){
    /*
            ______ introduce una variabile a 0
                    ______ espressione di controllo, il loop continua fino a che i sia minore di 10
                            ___ incrementa i di 1*/
    for (int i = 1; i <= 10; i++)
        printf("%d\n",i);
    return 0;
}