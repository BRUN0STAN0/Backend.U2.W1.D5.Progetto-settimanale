#include <stdio.h>
int main(){
    char array[] = "Br9un4oe";
    int contatorelettere = 0;
    int contatorenumeri = 0;

    int lunghezza = sizeof(array) / sizeof(char);

    for (int i = 0; i < lunghezza; i++) {
        if (array[i] >= '0' && array[i] <= '9')
            printf("Ho contato un numero,   %c\n",array[i])+ ++contatorenumeri;

        else if ((array[i] >= 'a' && array[i] <= 'z') || 
                 (array[i] >= 'A' && array[i] <= 'Z'))
                printf("Ho contato una lettera, %c\n",array[i])+ ++contatorelettere;
                
    }

    printf("numeri = %d\nlettere = %d\n", contatorenumeri, contatorelettere);

    return 0;
}