#include <stdio.h>
int main(){
    int a = 20;
    int b = 8;
    int c;

    // Operatore Relazionale
    if (a > b) {
        c = a;
    } else {
        c = b;
    }
    printf("%d\n",c);

    // Operatore Condizionale
    /* 
        ____Domanda
               __Vero
                   __Falso
                        .*/
    c = a < b? a : b;
    printf("%d\n",c);

    return 0;
}