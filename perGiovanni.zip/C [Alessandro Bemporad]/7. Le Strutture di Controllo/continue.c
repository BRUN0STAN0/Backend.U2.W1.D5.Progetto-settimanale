#include <stdio.h>
int main(){
    for (int i = 0; i < 10; i++){
        // SALTA I NUMERI 2 e 6.
        if (i == 2 || i == 6)
            continue;

        printf("%d\n",i);
    }
    return 0;
}