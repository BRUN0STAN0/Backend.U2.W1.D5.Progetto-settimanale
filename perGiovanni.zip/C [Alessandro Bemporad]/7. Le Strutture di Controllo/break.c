#include <stdio.h>
int main(){

    // Loop infinito, gli mettiamo un break.
    for (int i = 0;  ; i++){
        printf("%d\n", i);
        if (i == 325)
            break;
    }
    return 0;
}